# PRIME SONG AI

A responsive AI music studio frontend with a small Flask backend, ready for GitHub + Render.

## Deploy on Render
1. Create a GitHub repository named `prime-song-ai`.
2. Upload all files in this folder to the repository root.
3. In Render, choose **New + → Blueprint** and connect the repository. Render reads `render.yaml`.
4. After the service is created, open **Environment** and add `MUSIC_API_URL` and `MUSIC_API_KEY` for your chosen music-generation provider.
5. Redeploy.

## Music API connection
The interface and secure server-side request route are included. Actual song generation requires a music-generation provider with an API. The current adapter sends JSON fields for prompt, genres, mood, language, vocals, length, lyrics and instrumental mode, and expects a JSON response containing either `audio_url` or `job_id`.

Different providers use different request and response formats. Do not paste API keys into `index.html` or commit them to GitHub. Once you choose a provider or share its API documentation, adapt `server.py` to its exact API contract. Asynchronous providers will also need a status-check route to retrieve completed audio.
